# Python notebooks
Code material for the youtube channel: https://www.youtube.com/channel/UC8fwFSM3zKpa-huYkubwEpA
